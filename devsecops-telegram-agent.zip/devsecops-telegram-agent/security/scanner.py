"""
Module de Scan de Sécurité DevSecOps
Orchestre les différents outils de sécurité :
- SAST : Semgrep (analyse statique du code source)
- Dépendances : pip-audit / safety (vulnérabilités dans les packages)
- Docker : Trivy (scan d'images Docker)
- Secrets : Gitleaks (détection de secrets dans le code)
"""

import os
import json
import logging
import subprocess
import tempfile

logger = logging.getLogger(__name__)


class SecurityScanner:
    """
    Orchestre les scans de sécurité et normalise les résultats.
    
    Chaque scan retourne un dict unifié :
    {
        "scanner": str,
        "scan_type": str,
        "vulnerabilities": [
            {
                "id": str,
                "title": str,
                "severity": "critical|high|medium|low|info",
                "description": str,
                "file": str (optionnel),
                "line": int (optionnel),
                "fix": str (optionnel),
            }
        ],
        "summary": {"critical": int, "high": int, "medium": int, "low": int},
        "raw_output": str,
    }
    """

    def __init__(self):
        self.project_path = os.environ.get("PROJECT_PATH", "/app/target")
        self.docker_image = os.environ.get("DOCKER_IMAGE", "myapp:latest")

    def run_scan(self, scan_type: str) -> dict:
        """
        Point d'entrée principal. Lance le scan du type demandé.
        
        scan_type: "sast" | "deps" | "docker" | "secrets" | "all"
        """
        scan_methods = {
            "sast": self.run_sast,
            "deps": self.run_dependency_scan,
            "docker": self.run_docker_scan,
            "secrets": self.run_secret_scan,
        }

        if scan_type == "all":
            all_results = {"vulnerabilities": [], "summary": {}, "scanners": []}
            for name, method in scan_methods.items():
                try:
                    result = method()
                    all_results["vulnerabilities"].extend(result.get("vulnerabilities", []))
                    all_results["scanners"].append(name)
                    logger.info(f"Scan {name} terminé : {len(result.get('vulnerabilities', []))} findings")
                except Exception as e:
                    logger.error(f"Erreur scan {name}: {e}")
            all_results["summary"] = self._compute_summary(all_results["vulnerabilities"])
            return all_results

        if scan_type not in scan_methods:
            raise ValueError(f"Type de scan inconnu: {scan_type}. Utilisez: {list(scan_methods.keys())}")

        return scan_methods[scan_type]()

    # ──────────────────────────────────────────
    # SAST — Analyse statique (Semgrep)
    # ──────────────────────────────────────────

    def run_sast(self) -> dict:
        """
        SAST avec Semgrep — détecte les vulnérabilités dans le code source.
        Rulesets utilisés: p/python, p/javascript, p/owasp-top-ten
        """
        logger.info("🔍 Lancement scan SAST (Semgrep)...")
        try:
            result = subprocess.run(
                [
                    "semgrep",
                    "--config", "p/python",
                    "--config", "p/owasp-top-ten",
                    "--json",
                    "--quiet",
                    self.project_path,
                ],
                capture_output=True,
                text=True,
                timeout=120,
            )
            data = json.loads(result.stdout) if result.stdout else {"results": []}
            vulns = self._parse_semgrep_results(data)
        except FileNotFoundError:
            logger.warning("Semgrep non installé — utilisation des données de démonstration")
            vulns = self._mock_sast_results()
        except Exception as e:
            logger.error(f"Erreur SAST: {e}")
            vulns = []

        return {
            "scanner": "Semgrep",
            "scan_type": "sast",
            "vulnerabilities": vulns,
            "summary": self._compute_summary(vulns),
        }

    def _parse_semgrep_results(self, data: dict) -> list:
        """Normalise les résultats Semgrep"""
        vulns = []
        for finding in data.get("results", []):
            severity_map = {"ERROR": "high", "WARNING": "medium", "INFO": "low"}
            vulns.append({
                "id": finding.get("check_id", ""),
                "title": finding.get("extra", {}).get("message", ""),
                "severity": severity_map.get(finding.get("extra", {}).get("severity", "INFO"), "low"),
                "file": finding.get("path", ""),
                "line": finding.get("start", {}).get("line", 0),
                "fix": finding.get("extra", {}).get("fix", ""),
                "description": finding.get("extra", {}).get("metadata", {}).get("description", ""),
            })
        return vulns

    def _mock_sast_results(self) -> list:
        """Données de démonstration pour le SAST (quand Semgrep n'est pas dispo)"""
        return [
            {
                "id": "python.lang.security.dangerous-subprocess-use",
                "title": "Utilisation dangereuse de subprocess sans validation",
                "severity": "high",
                "file": "app/utils.py",
                "line": 42,
                "fix": "Utiliser subprocess avec shell=False et une liste d'arguments",
                "description": "subprocess.call avec shell=True peut mener à une injection de commande",
            },
            {
                "id": "python.flask.security.insecure-deserialization",
                "title": "Désérialisation non sécurisée avec pickle",
                "severity": "critical",
                "file": "app/models.py",
                "line": 87,
                "fix": "Utiliser json.loads() à la place de pickle.loads()",
                "description": "pickle.loads() sur des données non fiables permet l'exécution de code",
            },
            {
                "id": "python.lang.security.hardcoded-password",
                "title": "Mot de passe codé en dur",
                "severity": "medium",
                "file": "config.py",
                "line": 12,
                "fix": "Utiliser les variables d'environnement ou un gestionnaire de secrets",
                "description": "Identifiant hardcodé dans le code source",
            },
        ]

    # ──────────────────────────────────────────
    # Scan Dépendances (pip-audit)
    # ──────────────────────────────────────────

    def run_dependency_scan(self) -> dict:
        """
        Scan des dépendances Python avec pip-audit.
        Vérifie les CVEs connues dans les packages installés.
        """
        logger.info("📦 Lancement scan dépendances (pip-audit)...")
        try:
            result = subprocess.run(
                ["pip-audit", "--format", "json", "--output", "-"],
                capture_output=True,
                text=True,
                timeout=120,
            )
            data = json.loads(result.stdout) if result.stdout else []
            vulns = self._parse_pip_audit_results(data)
        except FileNotFoundError:
            logger.warning("pip-audit non installé — données de démonstration")
            vulns = self._mock_deps_results()
        except Exception as e:
            logger.error(f"Erreur scan deps: {e}")
            vulns = []

        return {
            "scanner": "pip-audit",
            "scan_type": "deps",
            "vulnerabilities": vulns,
            "summary": self._compute_summary(vulns),
        }

    def _parse_pip_audit_results(self, data: list) -> list:
        """Normalise les résultats pip-audit"""
        vulns = []
        for pkg in data:
            for vuln in pkg.get("vulns", []):
                vulns.append({
                    "id": vuln.get("id", ""),
                    "title": f"{pkg.get('name')} {pkg.get('version')} — {vuln.get('id')}",
                    "severity": vuln.get("fix_versions", [""])[0] and "high" or "medium",
                    "description": vuln.get("description", ""),
                    "fix": f"Mettre à jour vers {', '.join(vuln.get('fix_versions', ['version plus récente']))}",
                })
        return vulns

    def _mock_deps_results(self) -> list:
        return [
            {
                "id": "CVE-2023-32681",
                "title": "requests 2.28.0 — SSRF via Proxy-Authorization",
                "severity": "medium",
                "description": "requests permet une fuite de credentials vers des hôtes non prévus",
                "fix": "Mettre à jour requests vers >= 2.31.0",
            },
            {
                "id": "CVE-2024-35195",
                "title": "cryptography 41.0.0 — NULL pointer dereference",
                "severity": "high",
                "description": "Vulnérabilité dans le parsing de certificats X.509",
                "fix": "Mettre à jour cryptography vers >= 42.0.4",
            },
        ]

    # ──────────────────────────────────────────
    # Scan Docker (Trivy)
    # ──────────────────────────────────────────

    def run_docker_scan(self) -> dict:
        """
        Scan de l'image Docker avec Trivy.
        Détecte les CVEs dans l'OS de base et les couches de l'image.
        """
        logger.info(f"🐳 Lancement scan Docker (Trivy) — image: {self.docker_image}...")
        try:
            result = subprocess.run(
                [
                    "trivy", "image",
                    "--format", "json",
                    "--quiet",
                    self.docker_image,
                ],
                capture_output=True,
                text=True,
                timeout=300,
            )
            data = json.loads(result.stdout) if result.stdout else {}
            vulns = self._parse_trivy_results(data)
        except FileNotFoundError:
            logger.warning("Trivy non installé — données de démonstration")
            vulns = self._mock_docker_results()
        except Exception as e:
            logger.error(f"Erreur scan Docker: {e}")
            vulns = []

        return {
            "scanner": "Trivy",
            "scan_type": "docker",
            "vulnerabilities": vulns,
            "summary": self._compute_summary(vulns),
        }

    def _parse_trivy_results(self, data: dict) -> list:
        """Normalise les résultats Trivy"""
        vulns = []
        severity_map = {"CRITICAL": "critical", "HIGH": "high", "MEDIUM": "medium", "LOW": "low"}
        for result in data.get("Results", []):
            for vuln in result.get("Vulnerabilities", []):
                vulns.append({
                    "id": vuln.get("VulnerabilityID", ""),
                    "title": f"{vuln.get('PkgName')} — {vuln.get('VulnerabilityID')}",
                    "severity": severity_map.get(vuln.get("Severity", "LOW"), "low"),
                    "description": vuln.get("Description", ""),
                    "fix": vuln.get("FixedVersion", "Pas de fix disponible"),
                })
        return vulns

    def _mock_docker_results(self) -> list:
        return [
            {
                "id": "CVE-2023-44487",
                "title": "openssl 3.0.8 — HTTP/2 Rapid Reset Attack",
                "severity": "critical",
                "description": "Vulnérabilité DDoS dans l'implémentation HTTP/2",
                "fix": "Mettre à jour l'image de base vers python:3.11-slim-bookworm",
            },
            {
                "id": "CVE-2024-2511",
                "title": "libssl1.1 — Memory leak dans TLSv1.3",
                "severity": "low",
                "description": "Fuite mémoire dans les sessions TLS",
                "fix": "openssl >= 3.0.13",
            },
        ]

    # ──────────────────────────────────────────
    # Scan Secrets (Gitleaks)
    # ──────────────────────────────────────────

    def run_secret_scan(self) -> dict:
        """
        Détection de secrets avec Gitleaks.
        Cherche : clés API, tokens, passwords, connexions DB dans le code et l'historique git.
        """
        logger.info("🔑 Lancement détection secrets (Gitleaks)...")
        try:
            with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as f:
                report_file = f.name

            result = subprocess.run(
                [
                    "gitleaks", "detect",
                    "--source", self.project_path,
                    "--report-format", "json",
                    "--report-path", report_file,
                    "--no-banner",
                ],
                capture_output=True,
                text=True,
                timeout=60,
            )
            with open(report_file) as f:
                data = json.load(f)
            vulns = self._parse_gitleaks_results(data)
        except FileNotFoundError:
            logger.warning("Gitleaks non installé — données de démonstration")
            vulns = self._mock_secrets_results()
        except Exception as e:
            logger.error(f"Erreur scan secrets: {e}")
            vulns = []

        return {
            "scanner": "Gitleaks",
            "scan_type": "secrets",
            "vulnerabilities": vulns,
            "summary": self._compute_summary(vulns),
        }

    def _parse_gitleaks_results(self, data: list) -> list:
        """Normalise les résultats Gitleaks"""
        vulns = []
        for finding in data or []:
            vulns.append({
                "id": finding.get("RuleID", ""),
                "title": f"Secret détecté : {finding.get('Description', '')}",
                "severity": "critical",  # Tout secret est critique
                "file": finding.get("File", ""),
                "line": finding.get("StartLine", 0),
                "description": f"Auteur: {finding.get('Author', 'N/A')} | Commit: {finding.get('Commit', 'N/A')[:8]}",
                "fix": "Révoquer immédiatement le secret et le supprimer de l'historique git",
            })
        return vulns

    def _mock_secrets_results(self) -> list:
        return [
            {
                "id": "generic-api-key",
                "title": "Secret détecté : Clé API en clair",
                "severity": "critical",
                "file": ".env.example",
                "line": 5,
                "description": "Auteur: dev@example.com | Commit: a1b2c3d4",
                "fix": "Révoquer la clé et utiliser des variables d'environnement",
            },
        ]

    # ──────────────────────────────────────────
    # UTILITAIRES
    # ──────────────────────────────────────────

    def _compute_summary(self, vulnerabilities: list) -> dict:
        """Calcule le résumé par niveau de sévérité"""
        summary = {"critical": 0, "high": 0, "medium": 0, "low": 0, "info": 0}
        for vuln in vulnerabilities:
            sev = vuln.get("severity", "info").lower()
            if sev in summary:
                summary[sev] += 1
        return summary