"""
Tests unitaires — Agent AI DevSecOps Telegram
Couvre : bot commands, agent AI, gitlab client, security scanner
Lancer : pytest tests/ -v --cov=. --cov-report=term-missing
"""

import json
import os
import pytest
from unittest.mock import MagicMock, patch, AsyncMock

# ── Charger les variables d'environnement de test ─────────────────
os.environ.setdefault("TELEGRAM_BOT_TOKEN", "fake_token_for_tests")
os.environ.setdefault("GITLAB_TOKEN",       "fake_gitlab_token")
os.environ.setdefault("GITLAB_PROJECT_ID",  "12345")
os.environ.setdefault("GITLAB_URL",         "https://gitlab.com")


# ══════════════════════════════════════════════════════════════════
# FIXTURES PARTAGÉES
# ══════════════════════════════════════════════════════════════════

@pytest.fixture
def mock_update():
    """Simule un objet Update Telegram avec un utilisateur et un message."""
    update = MagicMock()
    update.effective_user.first_name = "Salima"
    update.effective_user.id = 123456789
    update.message.reply_text = AsyncMock(return_value=MagicMock(
        edit_text=AsyncMock()
    ))
    update.message.text = "test message"
    return update


@pytest.fixture
def mock_context():
    """Simule le contexte Telegram (args, bot, job_queue...)."""
    context = MagicMock()
    context.args = []
    return context


@pytest.fixture
def agent():
    """Instancie l'agent AI avec Ollama mocké."""
    from agent.ai_agent import DevSecOpsAgent
    return DevSecOpsAgent()


@pytest.fixture
def gitlab_client():
    """Instancie le client GitLab."""
    from gitlab.gitlab_client import GitLabClient
    return GitLabClient()


@pytest.fixture
def scanner():
    """Instancie le scanner de sécurité."""
    from security.scanner import SecurityScanner
    return SecurityScanner()


# ══════════════════════════════════════════════════════════════════
# TESTS — AGENT AI
# ══════════════════════════════════════════════════════════════════

class TestDevSecOpsAgent:
    """Tests de l'agent AI (Ollama mocké pour ne pas nécessiter le serveur)."""

    def test_agent_initialisation(self, agent):
        """L'agent doit s'initialiser avec le bon modèle."""
        assert agent.model == "llama3"
        assert isinstance(agent.conversation_history, dict)

    def test_system_prompt_present(self, agent):
        """Le system prompt doit contenir les commandes DevSecOps."""
        content = agent.system_prompt["content"]
        assert "/status" in content
        assert "/run_pipeline" in content
        assert "/scan" in content
        assert "/deploy" in content
        assert "/logs" in content

    @patch("agent.ai_agent.chat")
    def test_ask_retourne_texte(self, mock_chat, agent):
        """ask() doit retourner le contenu du message Ollama."""
        mock_chat.return_value = {
            "message": {"content": "Pipeline en cours d'exécution."}
        }
        result = agent.ask("Quel est l'état du pipeline ?")
        assert result == "Pipeline en cours d'exécution."
        mock_chat.assert_called_once()

    @patch("agent.ai_agent.chat")
    def test_process_nlp_reponse_texte(self, mock_chat, agent):
        """process_natural_language() doit gérer une réponse texte normale."""
        mock_chat.return_value = {
            "message": {"content": "Le pipeline est en succès ✅"}
        }
        result = agent.process_natural_language("État du pipeline ?", user_id="user1")
        assert "succès" in result
        # L'historique doit être mis à jour
        assert len(agent.conversation_history["user1"]) == 3  # system + user + assistant

    @patch("agent.ai_agent.chat")
    def test_process_nlp_reponse_json_action(self, mock_chat, agent):
        """process_natural_language() doit exécuter une action si l'IA répond en JSON."""
        mock_chat.return_value = {
            "message": {"content": json.dumps({
                "action": "run_pipeline",
                "params": {"branch": "main"},
                "message": "Lancement du pipeline"
            })}
        }
        result = agent.process_natural_language("Lance le pipeline", user_id="user2")
        assert "pipeline" in result.lower()
        assert "main" in result

    @patch("agent.ai_agent.chat")
    def test_historique_tronque(self, mock_chat, agent):
        """L'historique ne doit pas dépasser 21 messages (system + 20)."""
        mock_chat.return_value = {"message": {"content": "ok"}}
        for i in range(15):
            agent.process_natural_language(f"message {i}", user_id="user3")
        assert len(agent.conversation_history["user3"]) <= 21

    def test_clear_history(self, agent):
        """clear_history() doit supprimer l'historique d'un utilisateur."""
        agent.conversation_history["user_test"] = [{"role": "user", "content": "test"}]
        agent.clear_history("user_test")
        assert "user_test" not in agent.conversation_history

    @patch("agent.ai_agent.chat")
    def test_analyze_security_results(self, mock_chat, agent):
        """analyze_security_results() doit retourner une analyse formatée."""
        mock_chat.return_value = {
            "message": {"content": "🔴 Score: 8/10 — 2 vulnérabilités critiques détectées."}
        }
        results = {
            "vulnerabilities": [
                {"id": "CVE-001", "title": "SQL Injection", "severity": "critical"},
            ],
            "summary": {"critical": 1, "high": 0, "medium": 0, "low": 0}
        }
        result = agent.analyze_security_results(results)
        assert len(result) > 0
        mock_chat.assert_called_once()

    @patch("agent.ai_agent.chat")
    def test_erreur_ollama_gere(self, mock_chat, agent):
        """Une erreur Ollama doit retourner un message d'erreur clair."""
        mock_chat.side_effect = Exception("Connection refused")
        result = agent.process_natural_language("test", user_id="user_err")
        assert "Erreur" in result or "erreur" in result

    def test_execute_action_run_pipeline(self, agent):
        """_execute_action() doit formater correctement run_pipeline."""
        result = agent._execute_action({
            "action": "run_pipeline",
            "params": {"branch": "develop"},
            "message": ""
        })
        assert "develop" in result

    def test_execute_action_scan(self, agent):
        """_execute_action() doit formater correctement scan."""
        result = agent._execute_action({
            "action": "scan",
            "params": {"type": "sast"},
            "message": ""
        })
        assert "sast" in result.lower()

    def test_execute_action_deploy(self, agent):
        """_execute_action() doit formater correctement deploy."""
        result = agent._execute_action({
            "action": "deploy",
            "params": {"env": "production"},
            "message": ""
        })
        assert "production" in result

    def test_execute_action_inconnu(self, agent):
        """_execute_action() avec action inconnue doit retourner le message."""
        result = agent._execute_action({
            "action": "unknown_action",
            "params": {},
            "message": "Action personnalisée"
        })
        assert result == "Action personnalisée"


# ══════════════════════════════════════════════════════════════════
# TESTS — GITLAB CLIENT
# ══════════════════════════════════════════════════════════════════

class TestGitLabClient:
    """Tests du client GitLab (API mockée)."""

    def test_client_initialisation(self, gitlab_client):
        """Le client doit lire les variables d'environnement."""
        assert gitlab_client.token == "fake_gitlab_token"
        assert gitlab_client.project_id == "12345"
        assert "gitlab.com" in gitlab_client.base_url

    def test_headers_contient_token(self, gitlab_client):
        """Les headers doivent contenir le PRIVATE-TOKEN."""
        assert "PRIVATE-TOKEN" in gitlab_client.headers
        assert gitlab_client.headers["PRIVATE-TOKEN"] == "fake_gitlab_token"

    @patch("gitlab.gitlab_client.requests.request")
    def test_get_latest_pipeline(self, mock_request, gitlab_client):
        """get_latest_pipeline() doit retourner le premier pipeline de la liste."""
        mock_response = MagicMock()
        mock_response.json.return_value = [
            {"id": 42, "status": "success", "ref": "main", "duration": 120}
        ]
        mock_response.raise_for_status = MagicMock()
        mock_request.return_value = mock_response

        result = gitlab_client.get_latest_pipeline()
        assert result["id"] == 42
        assert result["status"] == "success"

    @patch("gitlab.gitlab_client.requests.request")
    def test_get_latest_pipeline_vide(self, mock_request, gitlab_client):
        """get_latest_pipeline() doit gérer une liste vide."""
        mock_response = MagicMock()
        mock_response.json.return_value = []
        mock_response.raise_for_status = MagicMock()
        mock_request.return_value = mock_response

        result = gitlab_client.get_latest_pipeline()
        assert result["status"] == "none"
        assert result["id"] is None

    @patch("gitlab.gitlab_client.requests.request")
    def test_trigger_pipeline(self, mock_request, gitlab_client):
        """trigger_pipeline() doit envoyer une requête POST et retourner l'ID."""
        mock_response = MagicMock()
        mock_response.json.return_value = {
            "id": 99, "status": "pending", "web_url": "https://gitlab.com/..."
        }
        mock_response.raise_for_status = MagicMock()
        mock_request.return_value = mock_response

        result = gitlab_client.trigger_pipeline("feature/test")
        assert result["id"] == 99
        # Vérifier que c'est bien un POST
        call_args = mock_request.call_args
        assert call_args[0][0] == "POST"

    @patch("gitlab.gitlab_client.requests.request")
    def test_trigger_pipeline_avec_variables(self, mock_request, gitlab_client):
        """trigger_pipeline() doit passer les variables CI correctement."""
        mock_response = MagicMock()
        mock_response.json.return_value = {"id": 100, "status": "pending"}
        mock_response.raise_for_status = MagicMock()
        mock_request.return_value = mock_response

        gitlab_client.trigger_pipeline("main", variables={"ENV": "staging"})
        call_kwargs = mock_request.call_args[1]
        assert "json" in call_kwargs
        assert "variables" in call_kwargs["json"]

    @patch("gitlab.gitlab_client.requests.request")
    def test_cancel_pipeline(self, mock_request, gitlab_client):
        """cancel_pipeline() doit envoyer POST sur /pipelines/{id}/cancel."""
        mock_response = MagicMock()
        mock_response.json.return_value = {"id": 42, "status": "canceled"}
        mock_response.raise_for_status = MagicMock()
        mock_request.return_value = mock_response

        result = gitlab_client.cancel_pipeline(42)
        assert result["status"] == "canceled"

    @patch("gitlab.gitlab_client.requests.get")
    def test_get_logs(self, mock_get, gitlab_client):
        """get_logs() avec job_id doit retourner le texte des logs."""
        mock_response = MagicMock()
        mock_response.text = "Step 1: Installing dependencies\nStep 2: Running tests\nPassed!"
        mock_response.raise_for_status = MagicMock()
        mock_get.return_value = mock_response

        result = gitlab_client.get_logs(job_id=123)
        assert "Installing dependencies" in result

    @patch("gitlab.gitlab_client.requests.request")
    def test_trigger_deploy(self, mock_request, gitlab_client):
        """trigger_deploy() doit passer DEPLOY_ENV comme variable CI."""
        mock_response = MagicMock()
        mock_response.json.return_value = {"id": 55, "status": "pending"}
        mock_response.raise_for_status = MagicMock()
        mock_request.return_value = mock_response

        gitlab_client.trigger_deploy("staging")
        call_kwargs = mock_request.call_args[1]
        variables = {v["key"]: v["value"] for v in call_kwargs["json"]["variables"]}
        assert variables["DEPLOY_ENV"] == "staging"
        assert variables["TRIGGER_SOURCE"] == "telegram_bot"


# ══════════════════════════════════════════════════════════════════
# TESTS — SECURITY SCANNER
# ══════════════════════════════════════════════════════════════════

class TestSecurityScanner:
    """Tests du module de scan de sécurité."""

    def test_scanner_initialisation(self, scanner):
        """Le scanner doit s'initialiser avec les bons attributs."""
        assert hasattr(scanner, "project_path")
        assert hasattr(scanner, "docker_image")

    def test_run_scan_type_inconnu(self, scanner):
        """run_scan() avec un type inconnu doit lever ValueError."""
        with pytest.raises(ValueError) as exc_info:
            scanner.run_scan("invalid_type")
        assert "inconnu" in str(exc_info.value)

    @patch("security.scanner.subprocess.run")
    def test_run_sast_semgrep_absent(self, mock_run, scanner):
        """run_sast() doit utiliser les données mock si Semgrep n'est pas installé."""
        mock_run.side_effect = FileNotFoundError("semgrep not found")
        result = scanner.run_sast()
        assert result["scanner"] == "Semgrep"
        assert result["scan_type"] == "sast"
        assert len(result["vulnerabilities"]) > 0
        assert "summary" in result

    @patch("security.scanner.subprocess.run")
    def test_run_deps_pip_audit_absent(self, mock_run, scanner):
        """run_dependency_scan() doit utiliser les données mock si pip-audit absent."""
        mock_run.side_effect = FileNotFoundError("pip-audit not found")
        result = scanner.run_dependency_scan()
        assert result["scanner"] == "pip-audit"
        assert result["scan_type"] == "deps"
        assert len(result["vulnerabilities"]) > 0

    @patch("security.scanner.subprocess.run")
    def test_run_docker_scan_trivy_absent(self, mock_run, scanner):
        """run_docker_scan() doit utiliser les données mock si Trivy absent."""
        mock_run.side_effect = FileNotFoundError("trivy not found")
        result = scanner.run_docker_scan()
        assert result["scanner"] == "Trivy"
        assert result["scan_type"] == "docker"

    @patch("security.scanner.subprocess.run")
    def test_run_secret_scan_gitleaks_absent(self, mock_run, scanner):
        """run_secret_scan() doit utiliser les données mock si Gitleaks absent."""
        mock_run.side_effect = FileNotFoundError("gitleaks not found")
        result = scanner.run_secret_scan()
        assert result["scanner"] == "Gitleaks"
        assert result["scan_type"] == "secrets"

    @patch("security.scanner.subprocess.run")
    def test_run_scan_all(self, mock_run, scanner):
        """run_scan('all') doit agréger les résultats des 4 scanners."""
        mock_run.side_effect = FileNotFoundError("tools not found")
        result = scanner.run_scan("all")
        assert "vulnerabilities" in result
        assert "summary" in result
        assert "scanners" in result
        assert len(result["scanners"]) == 4

    def test_compute_summary(self, scanner):
        """_compute_summary() doit compter correctement par sévérité."""
        vulns = [
            {"severity": "critical"},
            {"severity": "critical"},
            {"severity": "high"},
            {"severity": "medium"},
            {"severity": "low"},
            {"severity": "low"},
        ]
        summary = scanner._compute_summary(vulns)
        assert summary["critical"] == 2
        assert summary["high"] == 1
        assert summary["medium"] == 1
        assert summary["low"] == 2

    def test_compute_summary_vide(self, scanner):
        """_compute_summary() avec liste vide doit retourner tout à zéro."""
        summary = scanner._compute_summary([])
        assert all(v == 0 for v in summary.values())

    def test_parse_semgrep_results(self, scanner):
        """_parse_semgrep_results() doit normaliser le format Semgrep."""
        data = {
            "results": [{
                "check_id": "python.lang.security.test",
                "path": "app/utils.py",
                "start": {"line": 42},
                "extra": {
                    "message": "Dangerous function",
                    "severity": "ERROR",
                    "fix": "Use safer alternative",
                    "metadata": {"description": "This is dangerous"}
                }
            }]
        }
        vulns = scanner._parse_semgrep_results(data)
        assert len(vulns) == 1
        assert vulns[0]["severity"] == "high"
        assert vulns[0]["file"] == "app/utils.py"
        assert vulns[0]["line"] == 42

    def test_parse_trivy_results(self, scanner):
        """_parse_trivy_results() doit normaliser le format Trivy."""
        data = {
            "Results": [{
                "Vulnerabilities": [{
                    "VulnerabilityID": "CVE-2023-0001",
                    "PkgName": "openssl",
                    "Severity": "CRITICAL",
                    "Description": "Remote code execution",
                    "FixedVersion": "3.0.13"
                }]
            }]
        }
        vulns = scanner._parse_trivy_results(data)
        assert len(vulns) == 1
        assert vulns[0]["severity"] == "critical"
        assert vulns[0]["id"] == "CVE-2023-0001"
        assert vulns[0]["fix"] == "3.0.13"

    def test_mock_sast_results_structure(self, scanner):
        """Les données mock SAST doivent avoir la structure correcte."""
        vulns = scanner._mock_sast_results()
        assert len(vulns) >= 1
        for v in vulns:
            assert "id" in v
            assert "title" in v
            assert "severity" in v
            assert v["severity"] in ["critical", "high", "medium", "low", "info"]

    def test_mock_secrets_results_toujours_critiques(self, scanner):
        """Les secrets détectés doivent toujours être critiques."""
        vulns = scanner._mock_secrets_results()
        for v in vulns:
            assert v["severity"] == "critical"


# ══════════════════════════════════════════════════════════════════
# TESTS — COMMANDES BOT (intégration légère)
# ══════════════════════════════════════════════════════════════════

class TestBotCommands:
    """Tests des handlers de commandes Telegram (Update mocké)."""

    @pytest.mark.asyncio
    async def test_start_command(self, mock_update, mock_context):
        """La commande /start doit envoyer un message de bienvenue."""
        from bot.main import start
        await start(mock_update, mock_context)
        mock_update.message.reply_text.assert_called_once()
        call_kwargs = mock_update.message.reply_text.call_args
        # Le message doit contenir le prénom et des commandes
        text = call_kwargs[0][0] if call_kwargs[0] else call_kwargs[1].get("text", "")
        assert "Salima" in text or "DevSecOps" in text

    @pytest.mark.asyncio
    @patch("bot.main.gitlab_client")
    async def test_status_command_succes(self, mock_gitlab, mock_update, mock_context):
        """La commande /status doit afficher les infos du pipeline."""
        mock_gitlab.get_latest_pipeline.return_value = {
            "id": 42, "status": "success", "ref": "main",
            "user": {"name": "Alice"}, "duration": 95, "created_at": "2025-01-01"
        }
        from bot.main import status
        await status(mock_update, mock_context)
        mock_update.message.reply_text.assert_called_once()

    @pytest.mark.asyncio
    @patch("bot.main.gitlab_client")
    async def test_status_command_erreur(self, mock_gitlab, mock_update, mock_context):
        """La commande /status doit gérer les erreurs GitLab."""
        mock_gitlab.get_latest_pipeline.side_effect = Exception("API Error")
        from bot.main import status
        await status(mock_update, mock_context)
        # Doit quand même répondre (message d'erreur)
        mock_update.message.reply_text.assert_called_once()

    @pytest.mark.asyncio
    @patch("bot.main.gitlab_client")
    async def test_run_pipeline_branche_defaut(self, mock_gitlab, mock_update, mock_context):
        """run_pipeline sans args doit utiliser 'main'."""
        mock_gitlab.trigger_pipeline.return_value = {
            "id": 55, "web_url": "https://gitlab.com/pipeline/55"
        }
        mock_context.args = []
        from bot.main import run_pipeline
        await run_pipeline(mock_update, mock_context)
        mock_gitlab.trigger_pipeline.assert_called_once_with("main")

    @pytest.mark.asyncio
    @patch("bot.main.gitlab_client")
    async def test_run_pipeline_branche_specifique(self, mock_gitlab, mock_update, mock_context):
        """run_pipeline avec arg doit utiliser la branche spécifiée."""
        mock_gitlab.trigger_pipeline.return_value = {
            "id": 56, "web_url": "https://gitlab.com/pipeline/56"
        }
        mock_context.args = ["feature/auth"]
        from bot.main import run_pipeline
        await run_pipeline(mock_update, mock_context)
        mock_gitlab.trigger_pipeline.assert_called_once_with("feature/auth")

    @pytest.mark.asyncio
    async def test_help_command(self, mock_update, mock_context):
        """/help doit lister toutes les commandes disponibles."""
        from bot.main import help_command
        await help_command(mock_update, mock_context)
        mock_update.message.reply_text.assert_called_once()
        call_args = mock_update.message.reply_text.call_args[0][0]
        assert "/run_pipeline" in call_args
        assert "/scan" in call_args
        assert "/deploy" in call_args
        assert "/logs" in call_args

    @pytest.mark.asyncio
    @patch("bot.main.agent")
    async def test_handle_message_nlp(self, mock_agent, mock_update, mock_context):
        """Les messages texte doivent être traités par l'agent AI."""
        mock_agent.process_natural_language.return_value = "🔍 Scan en cours..."
        mock_update.message.text = "Lance un scan de sécurité"
        from bot.main import handle_message
        await handle_message(mock_update, mock_context)
        mock_agent.process_natural_language.assert_called_once()