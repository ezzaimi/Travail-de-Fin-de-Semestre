"""
Bot Telegram principal - Agent AI DevSecOps
Gère les commandes et délègue à l'agent AI pour le traitement intelligent
"""

from dotenv import load_dotenv
load_dotenv()

import logging
import os

LOG_FILE = os.getenv("LOG_FILE", "logs/bot.log")
os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)

logging.FileHandler(LOG_FILE)
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application,
    CommandHandler,
    CallbackQueryHandler,
    MessageHandler,
    filters,
    ContextTypes,
)
from agent.ai_agent import DevSecOpsAgent
from gitlab.gitlab_client import GitLabClient
from security.scanner import SecurityScanner

# Configuration du logging
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
    handlers=[
        logging.FileHandler("logs/bot.log"),
        logging.StreamHandler(),
    ],
)
logger = logging.getLogger(__name__)

# Initialisation des composants
agent = DevSecOpsAgent()
gitlab_client = GitLabClient()
scanner = SecurityScanner()

# ──────────────────────────────────────────
# COMMANDES TELEGRAM
# ──────────────────────────────────────────

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    /start — Message de bienvenue avec présentation des fonctionnalités
    """
    user = update.effective_user
    keyboard = [
        [
            InlineKeyboardButton("🚀 Lancer Pipeline", callback_data="run_pipeline"),
            InlineKeyboardButton("📊 Statut", callback_data="status"),
        ],
        [
            InlineKeyboardButton("🔒 Scan Sécurité", callback_data="scan"),
            InlineKeyboardButton("🐳 Deploy", callback_data="deploy"),
        ],
        [
            InlineKeyboardButton("📋 Logs", callback_data="logs"),
            InlineKeyboardButton("❓ Aide", callback_data="help"),
        ],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)

    welcome_msg = (
        f"👋 Bonjour *{user.first_name}* !\n\n"
        f"🤖 Je suis votre *Agent AI DevSecOps*.\n"
        f"Je contrôle votre pipeline CI/CD, lance des scans de sécurité "
        f"et déploie vos applications — *tout depuis Telegram*.\n\n"
        f"━━━━━━━━━━━━━━━━━━━━\n"
        f"📌 *Commandes disponibles :*\n"
        f"`/status` — État du pipeline\n"
        f"`/run_pipeline` — Lancer un pipeline\n"
        f"`/scan` — Scan de sécurité\n"
        f"`/deploy` — Déployer l'application\n"
        f"`/logs` — Voir les derniers logs\n"
        f"`/help` — Aide complète\n"
        f"━━━━━━━━━━━━━━━━━━━━\n\n"
        f"💡 Vous pouvez aussi me parler naturellement !"
    )
    await update.message.reply_text(
        welcome_msg,
        parse_mode="Markdown",
        reply_markup=reply_markup,
    )


async def status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    /status — Récupère l'état en temps réel du pipeline GitLab
    """
    msg = await update.message.reply_text("⏳ Récupération du statut...")
    try:
        pipeline_data = gitlab_client.get_latest_pipeline()
        status_emoji = {
            "success": "✅",
            "failed": "❌",
            "running": "🔄",
            "pending": "⏳",
            "canceled": "⛔",
            "skipped": "⏭️",
        }
        emoji = status_emoji.get(pipeline_data.get("status", ""), "❓")
        text = (
            f"{emoji} *Pipeline #{pipeline_data.get('id', 'N/A')}*\n\n"
            f"📌 Statut : `{pipeline_data.get('status', 'inconnu')}`\n"
            f"🌿 Branche : `{pipeline_data.get('ref', 'N/A')}`\n"
            f"👤 Déclenché par : `{pipeline_data.get('user', {}).get('name', 'N/A')}`\n"
            f"⏱️ Durée : `{pipeline_data.get('duration', 0)}s`\n"
            f"🕐 Créé : `{pipeline_data.get('created_at', 'N/A')}`\n"
        )
    except Exception as e:
        logger.error(f"Erreur statut: {e}")
        text = f"❌ Impossible de récupérer le statut : `{str(e)}`"

    await msg.edit_text(text, parse_mode="Markdown")


async def run_pipeline(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    /run_pipeline [branche] — Lance un pipeline GitLab sur la branche spécifiée
    """
    branch = context.args[0] if context.args else "main"
    msg = await update.message.reply_text(
        f"🚀 Lancement du pipeline sur la branche `{branch}`...",
        parse_mode="Markdown",
    )
    try:
        result = gitlab_client.trigger_pipeline(branch)
        text = (
            f"✅ *Pipeline lancé avec succès !*\n\n"
            f"🆔 ID : `{result.get('id')}`\n"
            f"🌿 Branche : `{branch}`\n"
            f"🔗 URL : {result.get('web_url', 'N/A')}\n\n"
            f"Utilisez `/status` pour suivre l'avancement."
        )
    except Exception as e:
        logger.error(f"Erreur run_pipeline: {e}")
        text = f"❌ Échec du lancement : `{str(e)}`"

    await msg.edit_text(text, parse_mode="Markdown")


async def scan(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    /scan [type] — Lance un scan de sécurité (sast/deps/docker/secrets)
    Types disponibles: sast, deps, docker, secrets, all
    """
    scan_type = context.args[0] if context.args else "all"
    keyboard = [
        [
            InlineKeyboardButton("🔍 SAST", callback_data="scan_sast"),
            InlineKeyboardButton("📦 Dépendances", callback_data="scan_deps"),
        ],
        [
            InlineKeyboardButton("🐳 Docker", callback_data="scan_docker"),
            InlineKeyboardButton("🔑 Secrets", callback_data="scan_secrets"),
        ],
        [InlineKeyboardButton("🔒 Tout scanner", callback_data="scan_all")],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)

    if scan_type == "all" and not context.args:
        await update.message.reply_text(
            "🔒 *Sélectionnez le type de scan :*",
            parse_mode="Markdown",
            reply_markup=reply_markup,
        )
        return

    await _execute_scan(update, scan_type)


async def _execute_scan(update: Update, scan_type: str):
    """Exécute le scan et envoie le rapport"""
    msg = await update.message.reply_text(
        f"🔍 Scan `{scan_type}` en cours...", parse_mode="Markdown"
    )
    try:
        results = scanner.run_scan(scan_type)
        # L'agent AI analyse les résultats et génère un rapport intelligent
        ai_analysis = agent.analyze_security_results(results)
        severity_emoji = {"critical": "🔴", "high": "🟠", "medium": "🟡", "low": "🟢"}
        report = f"📊 *Rapport de Scan — {scan_type.upper()}*\n\n"
        report += f"🤖 *Analyse AI :*\n{ai_analysis}\n\n"
        report += "━━━━━━━━━━━━━━━━━━━━\n"
        for vuln in results.get("vulnerabilities", [])[:5]:
            sev = vuln.get("severity", "low").lower()
            report += f"{severity_emoji.get(sev, '⚪')} `{vuln.get('id')}` — {vuln.get('title')}\n"
        if len(results.get("vulnerabilities", [])) > 5:
            report += f"\n_... et {len(results['vulnerabilities']) - 5} autres vulnérabilités_"
    except Exception as e:
        logger.error(f"Erreur scan {scan_type}: {e}")
        report = f"❌ Erreur scan `{scan_type}` : `{str(e)}`"

    await msg.edit_text(report, parse_mode="Markdown")


async def deploy(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    /deploy [env] — Déploie l'application (staging/production)
    """
    env = context.args[0] if context.args else "staging"

    # Confirmation avant déploiement production
    if env == "production":
        keyboard = [
            [
                InlineKeyboardButton("✅ Confirmer", callback_data=f"deploy_confirm_{env}"),
                InlineKeyboardButton("❌ Annuler", callback_data="deploy_cancel"),
            ]
        ]
        await update.message.reply_text(
            f"⚠️ *Déploiement en PRODUCTION !*\n\nÊtes-vous sûr ?",
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup(keyboard),
        )
        return

    await _execute_deploy(update, env)


async def _execute_deploy(update, env: str):
    """Exécute le déploiement"""
    msg = await update.message.reply_text(
        f"🐳 Déploiement sur `{env}`...", parse_mode="Markdown"
    )
    try:
        result = gitlab_client.trigger_deploy(env)
        text = (
            f"✅ *Déploiement réussi !*\n\n"
            f"🌐 Environnement : `{env}`\n"
            f"🆔 Job ID : `{result.get('id')}`\n"
            f"🔗 URL : {result.get('web_url', 'N/A')}"
        )
    except Exception as e:
        logger.error(f"Erreur déploiement {env}: {e}")
        text = f"❌ Échec déploiement `{env}` : `{str(e)}`"

    await msg.edit_text(text, parse_mode="Markdown")


async def logs(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    /logs [job_id] — Affiche les derniers logs du pipeline ou d'un job spécifique
    """
    job_id = context.args[0] if context.args else None
    msg = await update.message.reply_text("📋 Récupération des logs...")
    try:
        log_data = gitlab_client.get_logs(job_id)
        # Tronquer si trop long pour Telegram (4096 chars max)
        log_text = log_data[-3000:] if len(log_data) > 3000 else log_data
        text = f"📋 *Logs {'Job #' + str(job_id) if job_id else 'derniers'}:*\n\n```\n{log_text}\n```"
    except Exception as e:
        text = f"❌ Erreur récupération logs : `{str(e)}`"

    await msg.edit_text(text, parse_mode="Markdown")


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    /help — Affiche l'aide complète
    """
    help_text = (
        "❓ *Guide d'utilisation — Agent AI DevSecOps*\n\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "📌 *Commandes Pipeline :*\n"
        "`/run_pipeline [branche]` — Lance un pipeline\n"
        "`/status` — État du dernier pipeline\n"
        "`/logs [job_id]` — Voir les logs\n\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "🔒 *Commandes Sécurité :*\n"
        "`/scan` — Menu de scan\n"
        "`/scan sast` — Analyse statique du code\n"
        "`/scan deps` — Scan des dépendances\n"
        "`/scan docker` — Scan de l'image Docker\n"
        "`/scan secrets` — Détection de secrets\n"
        "`/scan all` — Tous les scans\n\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "🚀 *Commandes Déploiement :*\n"
        "`/deploy staging` — Déploie en staging\n"
        "`/deploy production` — Déploie en production\n\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "💡 *Astuce :* Vous pouvez me parler naturellement !\n"
        "Exemple : _\"Lance un scan de sécurité et déploie si tout est OK\"_"
    )
    await update.message.reply_text(help_text, parse_mode="Markdown")


async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    Gère les messages texte libres via l'agent AI (NLP)
    L'agent interprète la demande et exécute l'action appropriée
    """
    user_message = update.message.text
    msg = await update.message.reply_text("🤖 Analyse en cours...")
    try:
        # L'agent AI interprète la demande et retourne une action + réponse
        response = agent.process_natural_language(user_message)
        await msg.edit_text(response, parse_mode="Markdown")
    except Exception as e:
        logger.error(f"Erreur agent AI: {e}")
        await msg.edit_text(
            f"❌ Erreur de traitement : `{str(e)}`\nEssayez une commande directe comme `/help`",
            parse_mode="Markdown",
        )


async def button_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Gère les callbacks des boutons inline"""
    query = update.callback_query
    await query.answer()
    data = query.data

    if data == "status":
        await status(query, context)
    elif data == "run_pipeline":
        await query.edit_message_text("Utilisez `/run_pipeline [branche]`", parse_mode="Markdown")
    elif data.startswith("scan_"):
        scan_type = data.replace("scan_", "")
        await _execute_scan(query, scan_type)
    elif data.startswith("deploy_confirm_"):
        env = data.replace("deploy_confirm_", "")
        await _execute_deploy(query, env)
    elif data == "deploy_cancel":
        await query.edit_message_text("❌ Déploiement annulé.")
    elif data == "help":
        await help_command(query, context)


# ──────────────────────────────────────────
# POINT D'ENTRÉE
# ──────────────────────────────────────────

def main():
    """Lance le bot Telegram"""
    token = os.environ.get("TELEGRAM_BOT_TOKEN")
    if not token:
        raise ValueError("TELEGRAM_BOT_TOKEN manquant dans les variables d'environnement !")

    app = Application.builder().token(token).build()

    # Enregistrement des handlers
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("status", status))
    app.add_handler(CommandHandler("run_pipeline", run_pipeline))
    app.add_handler(CommandHandler("scan", scan))
    app.add_handler(CommandHandler("deploy", deploy))
    app.add_handler(CommandHandler("logs", logs))
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(CallbackQueryHandler(button_callback))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    logger.info("🤖 Bot Telegram DevSecOps démarré !")
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    import os
    os.makedirs("logs", exist_ok=True)
    main()