#!/usr/bin/env bash
# ══════════════════════════════════════════════════════════════════
# install.sh — Script d'installation de l'Agent AI DevSecOps
# ══════════════════════════════════════════════════════════════════
# Usage: chmod +x install.sh && ./install.sh

set -euo pipefail

# Couleurs
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; NC='\033[0m'

log()  { echo -e "${GREEN}[✓]${NC} $1"; }
warn() { echo -e "${YELLOW}[!]${NC} $1"; }
err()  { echo -e "${RED}[✗]${NC} $1"; exit 1; }
info() { echo -e "${BLUE}[i]${NC} $1"; }

echo ""
echo "╔══════════════════════════════════════════════╗"
echo "║   Agent AI DevSecOps — Installation         ║"
echo "╚══════════════════════════════════════════════╝"
echo ""

# ── 1. Vérification des prérequis ───────────────────────────────
info "Vérification des prérequis..."

command -v python3 >/dev/null 2>&1 || err "Python 3.11+ requis"
command -v docker >/dev/null 2>&1  || err "Docker requis"
command -v git >/dev/null 2>&1     || err "Git requis"

PYTHON_VERSION=$(python3 --version | cut -d' ' -f2 | cut -d'.' -f1,2)
log "Python $PYTHON_VERSION détecté"

DOCKER_VERSION=$(docker --version | cut -d' ' -f3 | tr -d ',')
log "Docker $DOCKER_VERSION détecté"

# ── 2. Création du fichier .env ──────────────────────────────────
if [ ! -f ".env" ]; then
    info "Création du fichier .env..."
    cat > .env << 'EOF'
# ══════════════════════════════════════════════════════════════════
# Configuration Agent AI DevSecOps
# IMPORTANT: Ne jamais committer ce fichier dans Git !
# ══════════════════════════════════════════════════════════════════

# ── Telegram ────────────────────────────────────────────────────
TELEGRAM_BOT_TOKEN=your_telegram_bot_token_here
TELEGRAM_CHAT_ID=your_telegram_chat_id_here

# ── Anthropic (Claude API) ───────────────────────────────────────
ANTHROPIC_API_KEY=your_anthropic_api_key_here

# ── GitLab CI/CD ────────────────────────────────────────────────
GITLAB_URL=https://gitlab.com
GITLAB_TOKEN=your_gitlab_token_here
GITLAB_PROJECT_ID=your_project_id_here

# ── Docker ──────────────────────────────────────────────────────
DOCKER_IMAGE=myapp:latest

# ── Redis ───────────────────────────────────────────────────────
REDIS_PASSWORD=change_this_password

# ── Grafana ─────────────────────────────────────────────────────
GRAFANA_USER=admin
GRAFANA_PASSWORD=change_this_password

# ── Sécurité ─────────────────────────────────────────────────────
PROJECT_PATH=/app/target
EOF
    warn "⚠️  Fichier .env créé. REMPLISSEZ les valeurs avant de continuer !"
    echo ""
    echo "  Éditez .env avec: nano .env"
    echo ""
    read -p "Appuyez sur Entrée une fois le .env configuré..."
fi

log ".env configuré"

# ── 3. Création des répertoires ──────────────────────────────────
info "Création de la structure de répertoires..."
mkdir -p logs screenshots docker/prometheus docker/grafana/{dashboards,datasources}

# Fichier prometheus minimal
cat > docker/prometheus/prometheus.yml << 'EOF'
global:
  scrape_interval: 15s

scrape_configs:
  - job_name: 'telegram-bot'
    static_configs:
      - targets: ['telegram-bot:8000']
EOF

log "Structure créée"

# ── 4. Installation des dépendances Python ───────────────────────
info "Installation des dépendances Python..."
python3 -m venv venv 2>/dev/null || true
source venv/bin/activate
pip install --upgrade pip -q
pip install -r requirements.txt -q
log "Dépendances installées"

# ── 5. Installation des outils de sécurité ──────────────────────
info "Installation des outils de sécurité..."

pip install semgrep pip-audit -q && log "Semgrep + pip-audit installés" || warn "Semgrep/pip-audit: installation manuelle requise"

# Trivy
if ! command -v trivy >/dev/null 2>&1; then
    warn "Trivy non détecté. Installation..."
    if command -v apt-get >/dev/null 2>&1; then
        curl -sfL https://raw.githubusercontent.com/aquasecurity/trivy/main/contrib/install.sh | sh -s -- -b /usr/local/bin v0.51.0 2>/dev/null \
            && log "Trivy installé" || warn "Trivy: installez manuellement depuis https://aquasecurity.github.io/trivy"
    fi
else
    log "Trivy déjà installé"
fi

# Gitleaks
if ! command -v gitleaks >/dev/null 2>&1; then
    warn "Gitleaks non détecté — sera utilisé via Docker dans le pipeline"
else
    log "Gitleaks détecté"
fi

# ── 6. Création des fichiers __init__.py ────────────────────────
touch bot/__init__.py agent/__init__.py gitlab/__init__.py security/__init__.py
log "Modules Python initialisés"

# ── 7. Vérification de la configuration ─────────────────────────
info "Vérification de la configuration..."
source .env 2>/dev/null || true

MISSING=""
[ -z "${TELEGRAM_BOT_TOKEN:-}" ] || [ "$TELEGRAM_BOT_TOKEN" = "your_telegram_bot_token_here" ] && MISSING="$MISSING TELEGRAM_BOT_TOKEN"
[ -z "${ANTHROPIC_API_KEY:-}" ]  || [ "$ANTHROPIC_API_KEY" = "your_anthropic_api_key_here" ] && MISSING="$MISSING ANTHROPIC_API_KEY"
[ -z "${GITLAB_TOKEN:-}" ]       || [ "$GITLAB_TOKEN" = "your_gitlab_token_here" ] && MISSING="$MISSING GITLAB_TOKEN"

if [ -n "$MISSING" ]; then
    warn "Variables manquantes dans .env :$MISSING"
else
    log "Configuration valide"
fi

# ── 8. Résumé ────────────────────────────────────────────────────
echo ""
echo "╔══════════════════════════════════════════════╗"
echo "║   Installation terminée !                   ║"
echo "╚══════════════════════════════════════════════╝"
echo ""
echo "  Commandes disponibles :"
echo ""
echo "  ▸ Démarrer le bot :      source venv/bin/activate && python -m bot.main"
echo "  ▸ Démarrer avec Docker : docker compose up -d"
echo "  ▸ Voir les logs :        docker compose logs -f telegram-bot"
echo "  ▸ Lancer les tests :     pytest tests/ -v"
echo ""
echo "  📖 Documentation : docs/rapport_final.pdf"
echo ""