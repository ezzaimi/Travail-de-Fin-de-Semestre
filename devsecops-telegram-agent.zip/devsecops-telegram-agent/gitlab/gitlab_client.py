"""
Client GitLab CI/CD
Gère toutes les interactions avec l'API GitLab :
- Pipelines (lancer, arrêter, relancer, état)
- Jobs (logs, statut)
- Déploiements (trigger manuels)
"""

from dotenv import load_dotenv
load_dotenv()

import os
import logging
import requests

logger = logging.getLogger(__name__)


class GitLabClient:
    """
    Wrapper autour de l'API GitLab REST v4.
    
    Variables d'environnement requises :
    - GITLAB_URL : URL de l'instance GitLab (ex: https://gitlab.com)
    - GITLAB_TOKEN : Token d'accès personnel (scope: api)
    - GITLAB_PROJECT_ID : ID numérique du projet
    """

    def __init__(self):
        self.base_url = os.environ.get("GITLAB_URL", "https://gitlab.com")
        self.token = os.environ.get("GITLAB_TOKEN")
        self.project_id = os.environ.get("GITLAB_PROJECT_ID")

        if not all([self.token, self.project_id]):
            logger.warning("Variables GitLab manquantes (GITLAB_TOKEN, GITLAB_PROJECT_ID)")

        self.headers = {
            "PRIVATE-TOKEN": self.token,
            "Content-Type": "application/json",
        }
        self.api_base = f"{self.base_url}/api/v4/projects/{self.project_id}"

    def _request(self, method: str, endpoint: str, **kwargs) -> dict:
        """Exécute une requête API avec gestion d'erreur"""
        url = f"{self.api_base}/{endpoint}"
        response = requests.request(
            method, url, headers=self.headers, timeout=30, **kwargs
        )
        response.raise_for_status()
        return response.json()

    # ──────────────────────────────────────────
    # PIPELINES
    # ──────────────────────────────────────────

    def get_latest_pipeline(self) -> dict:
        """
        Récupère le dernier pipeline du projet.
        Retourne: id, status, ref, duration, created_at, web_url
        """
        pipelines = self._request("GET", "pipelines", params={"per_page": 1})
        if not pipelines:
            return {"status": "none", "id": None}
        return pipelines[0]

    def get_pipeline(self, pipeline_id: int) -> dict:
        """Récupère les détails d'un pipeline spécifique"""
        return self._request("GET", f"pipelines/{pipeline_id}")

    def trigger_pipeline(self, branch: str = "main", variables: dict = None) -> dict:
        """
        Lance un nouveau pipeline sur la branche spécifiée.
        
        variables: dict de variables CI optionnelles
                   Ex: {"DEPLOY_ENV": "staging", "RUN_TESTS": "true"}
        """
        payload = {"ref": branch}
        if variables:
            payload["variables"] = [
                {"key": k, "value": v} for k, v in variables.items()
            ]
        result = self._request("POST", "pipeline", json=payload)
        logger.info(f"Pipeline #{result.get('id')} lancé sur {branch}")
        return result

    def cancel_pipeline(self, pipeline_id: int) -> dict:
        """Annule un pipeline en cours d'exécution"""
        result = self._request("POST", f"pipelines/{pipeline_id}/cancel")
        logger.info(f"Pipeline #{pipeline_id} annulé")
        return result

    def retry_pipeline(self, pipeline_id: int) -> dict:
        """Relance les jobs échoués d'un pipeline"""
        result = self._request("POST", f"pipelines/{pipeline_id}/retry")
        logger.info(f"Pipeline #{pipeline_id} relancé")
        return result

    def get_pipeline_jobs(self, pipeline_id: int) -> list:
        """Récupère tous les jobs d'un pipeline avec leur statut"""
        return self._request("GET", f"pipelines/{pipeline_id}/jobs")

    # ──────────────────────────────────────────
    # JOBS & LOGS
    # ──────────────────────────────────────────

    def get_logs(self, job_id: int = None) -> str:
        """
        Récupère les logs d'un job.
        Si job_id est None, récupère les logs du dernier job.
        """
        if job_id is None:
            # Récupère le dernier job du dernier pipeline
            pipeline = self.get_latest_pipeline()
            if not pipeline.get("id"):
                return "Aucun pipeline trouvé."
            jobs = self.get_pipeline_jobs(pipeline["id"])
            if not jobs:
                return "Aucun job trouvé."
            job_id = jobs[-1]["id"]

        url = f"{self.api_base}/jobs/{job_id}/trace"
        response = requests.get(url, headers=self.headers, timeout=30)
        response.raise_for_status()
        return response.text or "Logs vides."

    # ──────────────────────────────────────────
    # DÉPLOIEMENTS
    # ──────────────────────────────────────────

    def trigger_deploy(self, environment: str = "staging") -> dict:
        """
        Déclenche un déploiement via pipeline avec variable DEPLOY_ENV.
        Le .gitlab-ci.yml doit avoir un job 'deploy' conditionnel sur cette variable.
        """
        return self.trigger_pipeline(
            branch="main",
            variables={
                "DEPLOY_ENV": environment,
                "TRIGGER_SOURCE": "telegram_bot",
            },
        )

    def get_environments(self) -> list:
        """Liste les environnements de déploiement disponibles"""
        return self._request("GET", "environments")

    def get_deployments(self, environment: str = None) -> list:
        """Liste les déploiements, optionnellement filtrés par environnement"""
        params = {}
        if environment:
            params["environment"] = environment
        return self._request("GET", "deployments", params=params)

    # ──────────────────────────────────────────
    # SÉCURITÉ / RAPPORTS
    # ──────────────────────────────────────────

    def get_security_report(self, report_type: str = "sast") -> dict:
        """
        Récupère le rapport de sécurité GitLab (SAST, DAST, dependency_scanning).
        Disponible uniquement avec GitLab Ultimate/Gold.
        """
        pipeline = self.get_latest_pipeline()
        if not pipeline.get("id"):
            return {}
        try:
            return self._request(
                "GET",
                f"pipelines/{pipeline['id']}/security_findings",
                params={"report_type": report_type},
            )
        except requests.HTTPError as e:
            logger.warning(f"Rapport sécurité indisponible (plan requis): {e}")
            return {"error": "Rapport non disponible sur ce plan GitLab"}