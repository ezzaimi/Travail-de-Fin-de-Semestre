"""
Agent AI DevSecOps — Propulsé par Ollama (llama3)
Gère l'interprétation du langage naturel et l'analyse des résultats de sécurité
Fonctionne entièrement en local, sans clé API externe
"""

import json
import logging
from ollama import chat

logger = logging.getLogger(__name__)


class DevSecOpsAgent:
    """
    Agent intelligent basé sur Ollama (llama3) — 100% local.

    Responsabilités :
    - Interpréter les messages en langage naturel des utilisateurs
    - Mapper les intentions vers les commandes : /status, /run_pipeline,
      /scan, /deploy, /logs
    - Analyser les résultats des scans de sécurité
    - Générer des recommandations et rapports intelligents
    """

    def __init__(self):
        self.model = "llama3"
        self.conversation_history = {}  # Historique par user_id

        # System prompt injecté en tête de chaque conversation
        self.system_prompt = {
            "role": "system",
            "content": (
                "Tu es un Agent AI DevSecOps expert. "
                "Tu contrôles un pipeline CI/CD GitLab et gères la sécurité "
                "d'une application via Telegram.\n\n"
                "Commandes que tu peux déclencher :\n"
                "  /status          — Afficher l'état du pipeline\n"
                "  /run_pipeline    — Lancer un pipeline CI/CD\n"
                "  /scan [type]     — Lancer un scan (sast/deps/docker/secrets/all)\n"
                "  /deploy [env]    — Déployer (staging/production)\n"
                "  /logs [job_id]   — Afficher les logs\n\n"
                "Quand l'utilisateur exprime une intention qui correspond à une "
                "commande, réponds UNIQUEMENT avec un JSON valide, sans texte autour :\n"
                '{"action": "run_pipeline|scan|deploy|status|logs", '
                '"params": {}, "message": "texte affiché à l\'utilisateur"}\n\n'
                "Pour toute question informative, réponds en texte Markdown Telegram, "
                "en français, de façon concise et professionnelle."
            ),
        }

    # ──────────────────────────────────────────────────────────────
    # MÉTHODE PRINCIPALE — ask()
    # ──────────────────────────────────────────────────────────────

    def ask(self, prompt: str) -> str:
        """
        Envoie un prompt direct à llama3 et retourne la réponse brute.
        Utilisé pour les analyses ponctuelles (sécurité, pipeline...).
        """
        response = chat(
            model=self.model,
            messages=[
                self.system_prompt,
                {"role": "user", "content": prompt},
            ]
        )
        return response["message"]["content"]

    # ──────────────────────────────────────────────────────────────
    # TRAITEMENT LANGAGE NATUREL (avec historique)
    # ──────────────────────────────────────────────────────────────

    def process_natural_language(self, user_message: str, user_id: str = "default") -> str:
        """
        Traite un message utilisateur en maintenant l'historique de conversation.

        Exemples d'entrées reconnues :
        - "Lance un pipeline sur la branche feature/auth"  → /run_pipeline
        - "Quel est l'état du pipeline ?"                  → /status
        - "Lance un scan de sécurité complet"              → /scan all
        - "Déploie en staging"                             → /deploy staging
        - "Montre-moi les logs du dernier job"             → /logs
        """
        # Initialiser l'historique pour ce user si besoin
        if user_id not in self.conversation_history:
            self.conversation_history[user_id] = [self.system_prompt]

        # Ajouter le message utilisateur à l'historique
        self.conversation_history[user_id].append(
            {"role": "user", "content": user_message}
        )

        try:
            response = chat(
                model=self.model,
                messages=self.conversation_history[user_id],
            )
            assistant_message = response["message"]["content"]

            # Sauvegarder la réponse dans l'historique
            self.conversation_history[user_id].append(
                {"role": "assistant", "content": assistant_message}
            )

            # Limiter l'historique à 20 messages (10 échanges)
            # pour ne pas dépasser la fenêtre de contexte de llama3
            if len(self.conversation_history[user_id]) > 21:
                # Garder toujours le system prompt (index 0)
                self.conversation_history[user_id] = (
                    [self.conversation_history[user_id][0]]
                    + self.conversation_history[user_id][-20:]
                )

            # Si la réponse est un JSON → c'est une action à exécuter
            try:
                action_data = json.loads(assistant_message)
                return self._execute_action(action_data)
            except json.JSONDecodeError:
                # Réponse textuelle normale
                return assistant_message

        except Exception as e:
            logger.error(f"Erreur Ollama: {e}")
            return (
                f"❌ Erreur agent AI : `{str(e)}`\n"
                "Vérifiez qu'Ollama tourne bien (`ollama serve`) "
                "et que llama3 est installé (`ollama pull llama3`)."
            )

    # ──────────────────────────────────────────────────────────────
    # ANALYSE SÉCURITÉ
    # ──────────────────────────────────────────────────────────────

    def analyze_security_results(self, scan_results: dict) -> str:
        """
        Analyse les résultats d'un scan de sécurité.
        Génère un rapport priorisé avec recommandations.
        """
        prompt = (
            "Analyse ces résultats de scan de sécurité DevSecOps "
            "et génère un rapport concis en français :\n\n"
            f"{json.dumps(scan_results, indent=2, ensure_ascii=False)}\n\n"
            "Format de réponse (Markdown Telegram, max 500 caractères) :\n"
            "- Score de risque global (0-10)\n"
            "- Top 3 des problèmes critiques\n"
            "- Recommandation principale\n"
            "- Action immédiate suggérée"
        )
        try:
            return self.ask(prompt)
        except Exception as e:
            logger.error(f"Erreur analyse sécurité: {e}")
            return f"Analyse manuelle requise. Erreur : {str(e)}"

    # ──────────────────────────────────────────────────────────────
    # RECOMMANDATION PIPELINE
    # ──────────────────────────────────────────────────────────────

    def generate_pipeline_recommendation(self, pipeline_data: dict) -> str:
        """
        Génère une recommandation intelligente selon l'état du pipeline.
        """
        prompt = (
            f"Pipeline CI/CD en état : {pipeline_data.get('status')}\n"
            f"Durée : {pipeline_data.get('duration', 0)}s\n"
            f"Jobs échoués : {pipeline_data.get('failed_jobs', [])}\n\n"
            "En 2-3 phrases courtes, explique ce qui s'est passé "
            "et suggère la prochaine action. "
            "Réponds en français, format Telegram Markdown."
        )
        try:
            return self.ask(prompt)
        except Exception as e:
            return (
                f"Pipeline `{pipeline_data.get('status')}`. "
                "Consultez les logs pour plus de détails."
            )

    # ──────────────────────────────────────────────────────────────
    # EXÉCUTION D'ACTION
    # ──────────────────────────────────────────────────────────────

    def _execute_action(self, action_data: dict) -> str:
        """
        Traduit le JSON retourné par l'agent en message Telegram formaté.
        Le bot principal (main.py) lira ce message et exécutera la commande.
        """
        action = action_data.get("action", "info")
        params = action_data.get("params", {})
        message = action_data.get("message", "")

        action_messages = {
            "run_pipeline": (
                f"🚀 Lancement pipeline sur `{params.get('branch', 'main')}`\n"
                "Utilisez `/status` pour suivre l'avancement."
            ),
            "scan": (
                f"🔍 Scan `{params.get('type', 'all')}` en cours...\n"
                "Résultats disponibles dans quelques instants."
            ),
            "deploy": (
                f"🐳 Déploiement sur `{params.get('env', 'staging')}`\n"
                "Une confirmation sera requise pour la production."
            ),
            "status":  "📊 Récupération du statut du pipeline...",
            "logs":    f"📋 Chargement des logs {'job #' + str(params.get('job_id')) if params.get('job_id') else 'du dernier pipeline'}...",
            "info":    message,
        }

        return action_messages.get(action, message or "✅ Action traitée.")

    # ──────────────────────────────────────────────────────────────
    # UTILITAIRES
    # ──────────────────────────────────────────────────────────────

    def clear_history(self, user_id: str):
        """Réinitialise l'historique de conversation d'un utilisateur."""
        if user_id in self.conversation_history:
            del self.conversation_history[user_id]
            logger.info(f"Historique effacé pour user {user_id}")